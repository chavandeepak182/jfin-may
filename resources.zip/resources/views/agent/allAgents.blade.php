@extends('layouts.header')
@section('title')
@parent
JFS | Agents
@endsection
@section('content')

@section('content')
@parent
<style>
    #wrapper #content-wrapper #content{

        background-color: #f8f9fc;
        
    }
    .topbar {
    height: 4.375rem;
    background-color:#000;
}

.dataTables_filter {
    margin-right: 60px;
    text-align: right;
}


</style>
<!-- Breadcrumbs and Search Bar -->
<div class="card-header py-3">
    <div class="d-flex justify-content-between align-items-center">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="d-flex align-items-center">
            <ol class="breadcrumb m-0 bg-transparent">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">All Agents</li>
            </ol>
        </nav>
<div class="row no-gutters" style="gap:10px;margin-left:200px;"> 
    <!-- All Customer -->
    <div class="col-auto">
        <a href="{{ route('allUsers') }}"  style="text-decoration: none;">
            <div style="height:50px; width:150px; 
                        background: linear-gradient(135deg, #6a11cb, #2575fc); 
                        border-radius:12px; 
                        display:flex; align-items:center; justify-content:center;
                        color:white; font-weight:bold; 
                        box-shadow:0 4px 15px rgba(0,0,0,0.2);
                        transition:transform 0.2s ease, box-shadow 0.2s ease;">
                <span>All Customer</span>
            </div>
        </a>
    </div>

    <!-- All Channel Partner -->
    <div class="col-auto">
        <a href="{{ route('allPartners') }}" style="text-decoration: none;">
            <div style="height:50px; width:160px; 
                        background: linear-gradient(135deg, #ff512f, #dd2476); 
                        border-radius:12px; 
                        display:flex; align-items:center; justify-content:center;
                        color:white; font-weight:bold; 
                        box-shadow:0 4px 15px rgba(0,0,0,0.2);
                        transition:transform 0.2s ease, box-shadow 0.2s ease;">
                <span>All Channel Partner</span>
            </div>
        </a>
    </div>
</div>


<!-- Hover Effect -->
<style>
    a div:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }
</style>

        <!-- Search Bar -->
        
        <!-- Add User Button -->
        <button class="btn btn-primary ms-3" data-bs-toggle="modal" href="#addAgentView">
            <i class="fa fa-plus"></i> Add Agent
        </button>
    </div>
</div>

<link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet"/>
<link href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
<!-- export button -->
<link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css" rel="stylesheet"/>
<link href="{{ asset('theme') }}/dist-assets/css/sb-admin-2.min.css" rel="stylesheet">

<div class="row">
    <div class="col-12 grid-margin">
        <div class="card pt-3">
            <div class="card-body">
                <div class="table-responsive" id="user_table">
                    <table id="example" class="table">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Name </th>
                                <th> Email ID </th>
                                <th> Mobile Number </th>
                                <th> Pan No. </th>
                                  <th> Status </th>
                                <th> Action </th>
                            </tr>
                        </thead>
                        <tbody id="user_table_body">
                            @foreach($data['allAgents'] as $user)
                            <tr>
                                <td>{{ $user->id }}</td>
                                <td>
                                    <a href="javascript:void(0);" 
                                        class="user-link" 
                                        data-name="{{ $user->name }}" 
                                        data-email="{{ $user->email_id }}" 
                                        data-mobile="{{ $user->mobile_no }}" 
                                        data-dob="{{ $user->pan_no }}" 
                                        data-status="{{ $user->is_email_verify == 1 ? 'Active' : 'Inactive' }}">
                                        {{ $user->name }}
                                    </a>
                                    </td>

                                <td>{{ $user->email_id }}</td>
                                <td>{{ $user->mobile_no }}</td>
                                <td>{{ $user->pan_no }}</td>
                                <td>
                                            <label>
                                                <input type="radio" name="status_{{ $user->id }}" value="1"
                                                    onclick="updateStatus({{ $user->id }}, 1)"
                                                    {{ $user->is_email_verify == 1 ? 'checked' : '' }}>
                                                Active
                                            </label>
                                            <label>
                                                <input type="radio" name="status_{{ $user->id }}" value="0"
                                                    onclick="updateStatus({{ $user->id }}, 0)"
                                                    {{ $user->is_email_verify == 0 ? 'checked' : '' }}>
                                                Inactive
                                            </label>
                                        </td>
                                <td>
                                    <a class="btn btn-primary btn-xs edit" title="Edit" href="{{ url('editUser/'.$user->id) }}">
                                        <i class="fa fa-edit"></i>
                                    </a> 
                                    <button class="btn btn-danger btn-xs delete" title="Delete" data-id="{{ $user->id }}">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="float-right">
                        {{ $data['allAgents']->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Agent Modal -->
<div class="modal fade" id="addAgentView" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New agent</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="user" id="addAgent" method="post">
                @csrf   
                    <div class="row">
                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Name:</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" required>
                        </div>
                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Email ID:</label>
                            <input type="email" class="form-control" id="email_id" name="email_id" required>
                        </div>

                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                    </div>    

                    <div class="row">
                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Mobile Number:</label>
                            <input type="tel" class="form-control" id="v" name="mobile_no" required>
                        </div>

                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Date of Birth:</label>
                            <input type="date" class="form-control" id="dob" name="dob">
                        </div>

                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Address:</label>
                            <input type="tel" class="form-control" id="address" name="address">
                        </div>
                    </div>
   
                    <div class="row">
                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">City:</label>
                            <input type="text" class="form-control" id="city" name="city">
                        </div>

                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">State:</label>
                            <input type="text" class="form-control" id="state" name="state" >
                        </div>

                        <div class="form-group col-lg-4">
                            <label for="recipient-name" class="col-form-label">Pincode:</label>
                            <input type="text" class="form-control" id="pincode" name="pincode">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
               </form>
            </div>
        </div>
    </div> 
</div> 

<!-- User Details Modal -->
<div class="modal fade" id="userDetailsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-md modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">User Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><strong>Name:</strong> <span id="detail_name">-</span></li>
          <li class="list-group-item"><strong>Email:</strong> <span id="detail_email">-</span></li>
          <li class="list-group-item"><strong>Mobile:</strong> <span id="detail_mobile">-</span></li>
          <li class="list-group-item"><strong>DOB:</strong> <span id="detail_dob">-</span></li>
          <li class="list-group-item"><strong>Status:</strong> <span id="detail_status">-</span></li>
        </ul>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


@endsection

@section('script')
@parent

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

<!-- DataTables -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- Export Buttons -->
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>

<!-- SweetAlert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
$(document).ready(function () {
    // ✅ Initialize DataTable (only if table exists)
    if ($('#example').length) {
        $('#example').DataTable({
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
    }

    // ✅ Setup CSRF for all AJAX requests
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // ✅ Add Agent Form Submission
   $('#addAgent').on('submit', function (e) {
    e.preventDefault();

    $.ajax({
        url: "{{ route('insertAgent') }}",  // Laravel route
        type: "POST",
        data: new FormData(this),
        processData: false,
        contentType: false,
        dataType: 'json', // ✅ comma added here
        beforeSend: function () {
            $('span.error-text').text(''); // Clear old errors
        },
        success: function (data) {
            if (data.status === 0) {
                // Validation failed
                $.each(data.error, function (prefix, val) {
                    $('span.' + prefix + '_error').text(val[0]);
                    swal("Error!", val[0], "error");
                });
            } else if (data.status === 1) {
                // Success
                $('#addAgent')[0].reset();
                $('#addAgentView').modal('hide');
                swal({
                    title: "Success!",
                    text: data.msg,
                    icon: "success",
                    button: "OK"
                }).then(function () {
                    location.reload();
                });
            } else {
                // Unknown response
                swal("Error!", "Unexpected response from server.", "error");
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            swal("Error!", "Something went wrong. Please try again.", "error");
        }
    });
});

    // ✅ Delete Agent Handler (attached dynamically)
    $(document).on('click', '.delete', function () {
        var userId = $(this).data('id');
        deleteAgent(userId);
    });
});

// ✅ Delete Agent Function
function deleteAgent(id) {
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this agent!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            $.ajax({
                url: "{{ route('deleteAgent') }}", // Laravel route
                type: 'POST',
                dataType: 'json',
                data: {
                    user_id: id,
                    _token: '{{ csrf_token() }}'
                },
                success: function (response) {
                    if (response.status === 1) {
                        swal({
                            title: "Deleted!",
                            text: response.msg,
                            icon: "success",
                            button: "OK"
                        }).then(() => location.reload());
                    } else {
                        swal("Error!", response.error || "Delete failed.", "error");
                    }
                },
                error: function (xhr) {
                    console.error(xhr.responseText);
                    swal("Error!", "Failed to delete. Please try again.", "error");
                }
            });
        }
    });
}
</script>

<script>
    // Update User Status
           window.updateStatus = function(userId, status) {
                $.ajax({
                    url: "{{ route('updateUserStatus') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        user_id: userId,
                        is_email_verify: status
                    },
                    success: function(response) {
                        alert(response.message);
                    },
                    error: function(error) {
                        console.log(error);
                        alert("Error updating status");
                    }
                });
            };
</script>
<script>
    document.querySelectorAll('.user-link').forEach(link => {
    link.addEventListener('click', function() {
        document.getElementById('detail_name').textContent   = this.dataset.name;
        document.getElementById('detail_email').textContent  = this.dataset.email;
        document.getElementById('detail_mobile').textContent = this.dataset.mobile;
        document.getElementById('detail_dob').textContent    = this.dataset.dob;
        document.getElementById('detail_status').textContent = this.dataset.status;

        new bootstrap.Modal(document.getElementById('userDetailsModal')).show();
    });
});

</script>
@endsection
