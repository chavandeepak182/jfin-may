@extends('layouts.header')

@section('title')
    @parent
    Edit Loan
@endsection

@section('content')
    @parent
    <div class="card-header py-3">
        <div class="d-flex justify-content-between align-items-center">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="d-flex align-items-center">
                <ol class="breadcrumb m-0 bg-transparent">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('loans.index') }}">All Loans</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Loan</li>
                </ol>
            </nav>
            <!-- Add User Button -->
            <div>
                <a href="{{ route('admin.loans') }}" class="btn btn-secondary"><i class="bi bi-arrow-left-square me-2"></i>
                    Back</a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <div class="bg-white">
        <!-- <form id="editLoanForm" method="post" action="{{ route('updateLoan') }}"> -->
            <form id="editLoanForm" method="post" action="{{ route('admin.updateLoan') }}"
 enctype="multipart/form-data">

            @csrf
            <input type="hidden" name="loan_id" value="{{ old('loan_id', $loan->loan_id ?? '') }}">

            <div class="row justify-content-between">
                <!-- Left Section: Personal, Professional, Education & Loan Information -->
                <div class="col-md-7 p-5">
                    <!-- Personal Information -->
                    <div class="section mb-4">
                        <h3 class="h4 mb-2"><strong>Personal Information</strong></h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="user_id">User:</label>
                                        <input type="text" class="form-control" id="user_id" name="user_id"
                                            value="{{ $applyingUser->name ?? '' }}" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="loan_reference_id">Loan Id:</label>
                                        <input type="text" class="form-control" id="loan_reference_id"
                                            name="loan_reference_id"
                                            value="{{ old('loan_reference_id', $loan->loan_reference_id ?? '') }}" readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="mobile_no">Mobile No:</label>
                                        <input type="text" class="form-control" id="mobile_no" name="mobile_no"
                                            value="{{ old('mobile_no', $profile->mobile_no ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marital_status">Marital Status:</label>
                                        <select class="form-control" id="marital_status" name="marital_status">
                                            <option value="single"
                                                {{ old('marital_status', $profile->marital_status ?? '') == 'single' ? 'selected' : '' }}>
                                                Single</option>
                                            <option value="married"
                                                {{ old('marital_status', $profile->marital_status ?? '') == 'married' ? 'selected' : '' }}>
                                                Married</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dob">Date of Birth:</label>
                                        <input type="date" class="form-control" id="dob" name="dob"
                                            value="{{ old('dob', $profile->dob ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="residence_address">Residence Address:</label>
                                        <textarea class="form-control" id="residence_address" name="residence_address">{{ old('residence_address', $profile->residence_address ?? '') }}</textarea>
                                    </div>
                                </div>
                           
                               <div class="col-md-4">
    <div class="form-group">
        <label for="state">State:</label>
        <select class="form-control" id="state" name="state">
<option value="">Select State</option>

@foreach($states as $state)
<option value="{{ $state->id }}"
{{ old('state', $profile->state ?? '') == $state->id ? 'selected' : '' }}>
{{ $state->name }}
</option>
@endforeach

</select>
    </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                    <label for="city">City:</label>
                                   <select class="form-control" id="city" name="city">
                                        <option value="">Select City</option>

                                        @foreach($cities as $city)
                                        <option value="{{ $city->id }}"
                                        {{ old('city', $profile->city ?? '') == $city->id ? 'selected' : '' }}>
                                        {{ $city->city }}
                                        </option>
                                        @endforeach

                                        </select>        
 </div>
                            </div>
                            
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pincode">Pincode:</label>
                                        <input type="text" class="form-control" id="pincode" name="pincode"
                                            value="{{ old('pincode', $profile->pincode ?? '') }}">
                                    </div>
                                </div>
                            </div>
                    </div>

                    <!-- Professional Information -->
                    <div class="section mb-4">
                        <h3 class="h4 mb-2"><strong>Professional Information</strong></h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="company_name">Company Name:</label>
                                        <input type="text" class="form-control" id="company_name" name="company_name"
                                            value="{{ old('company_name', $professional->company_name ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="industry">Industry:</label>
                                        <input type="text" class="form-control" id="industry" name="industry"
                                            value="{{ old('industry', $professional->industry ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="company_address">Company Address:</label>
                                        <textarea class="form-control" id="company_address" name="company_address">{{ old('company_address', $professional->company_address ?? '') }}</textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="experience_year">Experience Year:</label>
                                        <input type="number" class="form-control" id="experience_year"
                                            name="experience_year"
                                            value="{{ old('experience_year', $professional->experience_year ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="designation">Designation:</label>
                                        <input type="text" class="form-control" id="designation" name="designation"
                                            value="{{ old('designation', $professional->designation ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="net_salary">Net Salary:</label>
                                        <input type="number" class="form-control" id="net_salary" name="netsalary"
                                            value="{{ old('netsalary', $professional->netsalary ?? '') }}">
                                    </div>
                                </div>
                            </div>
                    </div>

                    <!-- Loan Information -->
                    <div class="section mb-4">
                        <h3 class="h4 mb-2"><strong>Loan Information</strong></h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Loan Status:</label>
                                        <select name="status" class="form-control" id="status" required
                                            onchange="toggleRemarkBox(this.value)">
                                            <option value="approved"
                                                {{ old('status', $loan->status ?? '') == 'approved' ? 'selected' : '' }}>
                                                Approved</option>
                                            <option value="rejected"
                                                {{ old('status', $loan->status ?? '') == 'rejected' ? 'selected' : '' }}>
                                                Rejected</option>
                                            <option value="in process"
                                                {{ old('status', $loan->status ?? '') == 'in process' ? 'selected' : '' }}>
                                                In Process</option>
                                            <option value="disbursed"
                                                {{ old('status', $loan->status ?? '') == 'disbursed' ? 'selected' : '' }}>
                                                Disbursed</option>
                                            <option value="document pending"
                                                {{ old('status', $loan->status ?? '') == 'document pending' ? 'selected' : '' }}>
                                                Document Pending</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="loan_category_id">Loan Category:</label>
                                        <select name="loan_category_id" class="form-control" required>
                                            @foreach ($loanCategories as $category)
                                                <option value="{{ $category->loan_category_id }}"
                                                    {{ old('loan_category_id', $loan->loan_category_id ?? '') == $category->loan_category_id ? 'selected' : '' }}>
                                                    {{ $category->category_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="amount">Amount:</label>
                                        <input type="number" class="form-control" id="amount" name="amount"
                                            value="{{ old('amount', $loan->amount ?? '') }}" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tenure">Tenure:</label>
                                        <input type="number" class="form-control" id="tenure" name="tenure"
                                            value="{{ old('tenure', $loan->tenure ?? '') }}" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tenure">Tentative Approval</label>
                                        <select name="in_principle" id="in_principle" class="form-control">
                                            <option value="Yes" {{ $loan->in_principle == 'Yes' ? 'selected' : '' }}>
                                                Yes</option>
                                            <option value="No" {{ $loan->in_principle == 'No' ? 'selected' : '' }}>No
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Sanction Letter (Visible only if status is 'approved') -->
                                <div class="col-md-6">
                                    <div id="sanctionLetterBox" class="section mb-4" style="display: none;">
                                        <h3 class="h4 mb-2"><strong>Sanction Letter</strong></h4>
                                            <div class="form-group">
                                                

                                                <label for="sanction_letter">Upload Sanction Letter:</label>
                                                                <small id="sanctionLetterError"
                                                                    class="text-danger d-none mt-1">
                                                                    Please upload the sanction letter before disbursing the loan.
                                                                </small>
                                                <input type="file" class="form-control" id="sanction_letter"
                                                    name="sanction_letter">
                                                                                                @if ($loan->sanction_letter)
                                                    <small>
                                                        Current file:
                                                        <a href="{{ Storage::url($loan->sanction_letter) }}" target="_blank">
                                                            {{ basename($loan->sanction_letter) }}
                                                        </a>
                                                    </small>
                                                @endif


                                            </div>
                                    </div>
                                </div>
                            </div>
                    </div>

                    <div class="form-group" id="approvedAmountBox" style="display: none;">
                        <label for="amount_approved">Approved Amount:<span class="text-danger">*</span></label>
                                            <input
                            type="number"
                            class="form-control"
                            id="amountApproved"
                            name="amount_approved"
                            min="0"
                            max="{{ $loan->amount }}"
                            step="1"
                            value="{{ $loan->amount_approved ?? '' }}"
                        >
                        <small id="amountError" class="text-danger"></small>
                    </div>
                    <script>
document.querySelector("form").addEventListener("submit", function(e) {

    let approved = parseFloat(document.getElementById("amountApproved").value);
    let maxAmount = {{ $loan->amount ?? 0 }};

    if (isNaN(approved)) return;

    if (approved > maxAmount) {
        e.preventDefault();
        document.getElementById("amountError").innerText =
            "Approved amount cannot exceed loan amount";
    }
});
</script>

                    <div class="form-group" id="remark-box" style="display: none;">
                        <label for="remark">Remark:</label>
                        <textarea class="form-control" id="remark" name="remarks">{{ old('remarks') }}</textarea>
                    </div>



                    <div class="mt-4">
                        <button type="submit" class="btn btn-success px-4 py-3 rounded"><strong>UPDATE LOAN</strong></button>
                    </div>
                </div>

                <!-- Right Section: Documents -->
                <div class="col-md-4 bg-light p-5">
                    <div class="section mb-4">
                        <h3 class="h4 mb-2"><strong>Documents</strong></h4>
                            <!-- Documents -->
                            <h6>Uploaded:</h6>
                                                            @foreach ($documents as $doc)
                                                                <div class="col-md-12 mb-3">
                                                                <div class="document-wrapper">
                                    <a href="{{ Storage::url($doc->file_path) }}" target="_blank" style="display: flex; align-items: center; gap: 10px;">
                                        <img src="{{ Storage::url($doc->file_path) }}" 
                                            alt="{{ $doc->document_name }}" 
                                            style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; border: 1px solid #ddd;">
                                        <span>{{ $doc->document_name }}</span>
                                    </a>
                                </div>

                                </div>
                            @endforeach
                            <!-- Document Upload -->
                            <h6>Upload New Documents:</h6>
                            <div id="document-upload-section">
                                <div class="document-upload-row mb-3">
                                    <div class="row">
                                        <div class="col-md-12 mb-2">
                                            <input type="text" name="document_name[]" class="form-control"
                                                placeholder="Document Name">
                                        </div>
                                        <div class="col-md-12">
                                            <input type="file" name="documents[]" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="addDocumentUploadRow()">Add Another
                                Document</button>
                    </div>

                    <!-- Education Information -->
                    <!-- <div class="section mb-4 mt-5">
                        <h3 class="h4 mb-2"><strong>Education Information</strong></h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="qualification">Qualification:</label>
                                        <input type="text" class="form-control" id="qualification"
                                            name="qualification"
                                            value="{{ old('qualification', $education->qualification ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pass_year">Passing Year:</label>
                                        <input type="text" class="form-control" id="pass_year" name="pass_year"
                                            value="{{ old('pass_year', $education->pass_year ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="college_name">College Name:</label>
                                        <input type="text" class="form-control" id="college_name" name="college_name"
                                            value="{{ old('college_name', $education->college_name ?? '') }}">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="college_address">College Address:</label>
                                        <input type="text" class="form-control" id="college_address"
                                            name="college_address"
                                            value="{{ old('college_address', $education->college_address ?? '') }}">
                                    </div>
                                </div>
                            </div>
                    </div>
                </div> -->
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- <script>
        document.addEventListener('DOMContentLoaded', function() {

            $('#editLoanForm').submit(function(e) {
                e.preventDefault(); // Prevent the default form submission
                var form = this;
                var formData = new FormData(form);

                var submitButton = $(this).find('button[type="submit"]');
                submitButton.prop('disabled', true);
                
                var originalText = submitButton.html();
                submitButton.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...');

                $.ajax({
                    url: $(this).attr('action'),
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,

                    success: function(response) {
                        console.log(response); // Inspect the response object
                        Swal.fire({
                            title: response.msg ||
                                'Success!', // Fallback to 'Success!' if msg is not present
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href =
                                    "{{ route('admin.loans') }}"; // Redirect to the loans index
                            }
                        });
                    },
                    error: function(xhr) {
    let msg = 'Something went wrong';

    if (xhr.responseJSON?.message) {
        msg = xhr.responseJSON.message;
    }

    Swal.fire({
        title: 'Error!',
        text: msg,
        icon: 'error'
    });
}

                    complete: function() {
                        submitButton.prop('disabled', false);
                        submitButton.html(originalText);
                    }
                });
            });
        });
    </script> -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
$(document).ready(function () {

    $('#editLoanForm').on('submit', function (e) {
        e.preventDefault();

        const status = $('#status').val();
        const newFile = $('#sanction_letter').val();
        const hasExistingFile = "{{ $loan->sanction_letter ? 'yes' : '' }}";

        // ✅ ONLY WHEN DISBURSED
        if (
            status === 'disbursed' &&
            !newFile &&
            !hasExistingFile
        ) {
            $('#sanctionLetterError').removeClass('d-none');
            $('#sanction_letter').focus();
            return false; // ⛔ stop submit
        } else {
            $('#sanctionLetterError').addClass('d-none');
        }

        let formData = new FormData(this);
        let btn = $(this).find('button[type="submit"]');

        btn.prop('disabled', true);

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,

            success: function (response) {
                Swal.fire({
                    title: response.msg || 'Loan updated successfully',

                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = "{{ route('admin.loans') }}";
                });
            },

            error: function (xhr) {
                let msg = 'Something went wrong';
                if (xhr.responseJSON?.msg) {
                    msg = xhr.responseJSON.msg;
                }
                Swal.fire('Error', msg, 'error');
            },

            complete: function () {
                btn.prop('disabled', false);
            }
        });

        return false;
    });

});
</script>



    <script>
        function toggleRemarkBox(value) {
            var remarkBox = document.getElementById('remark-box');

            var approvedAmountBox = document.getElementById('approvedAmountBox');
            // approvedAmountBox.style.display = (status === 'disbursed' || status === 'approved') ? 'block' : 'none';

            const approvedAmountInput = document.getElementById('amountApproved');

            if (['rejected', 'approved', 'in process', 'disbursed'].includes(value)) {
                remarkBox.style.display = 'block';
            } else {
                remarkBox.style.display = 'none';
            }

            if (['approved', 'disbursed'].includes(value)) {
                approvedAmountBox.style.display = 'block';
                approvedAmountInput.setAttribute('required', 'required');
            } else {
                approvedAmountBox.style.display = 'none';
                approvedAmountInput.removeAttribute('required');
            }
            // return approvedAmountInput;
            // if (value === 'disbursed') {
            //     approvedAmountInput.setAttribute('required', 'required');
            // } else {
            //     approvedAmountInput.removeAttribute('required');
            // }

            // if (value === 'rejected' || value === 'approved' || value === 'in process' || value === 'disbursed') {
            //     remarkBox.style.display = 'block';
            //     approvedAmountBox.style.display = 'block';
            // } else {
            //     remarkBox.style.display = 'none';
            //     approvedAmountBox.style.display = 'none';
            // }
        }

        function addDocumentUploadRow() {
            var documentUploadSection = document.getElementById('document-upload-section');
            var newRow = document.createElement('div');
            newRow.className = 'document-upload-row mb-3';
            newRow.innerHTML = `
            <div class="row">
                <div class="col-md-12 mb-2">
                    <input type="text" name="document_name[]" class="form-control" placeholder="Document Name">
                </div>
                <div class="col-md-12">
                    <input type="file" name="documents[]" class="form-control">
                </div>
            </div>
        `;
            documentUploadSection.appendChild(newRow);
        }

       function toggleSanctionLetterBox(status) {
    if (status === 'approved' || status === 'disbursed') {
        document.getElementById('sanctionLetterBox').style.display = 'block';
    } else {
        document.getElementById('sanctionLetterBox').style.display = 'none';
    }
}

        // Initialize the form based on current status
      document.addEventListener('DOMContentLoaded', function() {
    var statusElement = document.getElementById('status');
    if (statusElement) {
        const statusValue = statusElement.value;
        toggleSanctionLetterBox(statusValue);
        toggleRemarkBox(statusValue);
    }
});

        // Listen for changes in the loan status
        document.getElementById('status').addEventListener('change', function() {
            toggleSanctionLetterBox(this.value);
        });
    </script>
<script>
$(document).ready(function(){

    function loadCities(state_id, selected_city = null){

        if(state_id){

            $.ajax({
                url: "/get-cities/" + state_id,
                type: "GET",
                success: function(data){

                    let cityDropdown = $('#city');
                    cityDropdown.empty();

                    cityDropdown.append('<option value="">Select City</option>');

                    $.each(data, function(index, city){

                        let selected = '';

                        if(selected_city == city.id){
                            selected = 'selected';
                        }

                        cityDropdown.append(
                            '<option value="'+city.id+'" '+selected+'>'+city.city+'</option>'
                        );

                    });

                }
            });

        }

    }

    // ✅ page load
    let state_id = $('#state').val();
    let selected_city = "{{ $profile->city }}";

    loadCities(state_id, selected_city);

    // ✅ state change
    $('#state').on('change', function(){

        let state_id = $(this).val();

        loadCities(state_id);

    });

});
</script>

@endsection
