@extends('layouts.header')

@section('title','Analytics')

@section('content')

<div class="analytics-page">

    <!-- ================= HEADER ================= -->
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h1>Analytics</h1>
            <p>Comprehensive analytics and reporting</p>
        </div>

        <div class="header-actions">
            <button class="btn btn-secondary">Export</button>
            <button class="btn btn-primary" onclick="openAddLead()">Add Lead</button>

            <button id="btnAddMIS" class="btn btn-primary d-none"
                    data-bs-toggle="modal" data-bs-target="#addMISView">
                + Add MIS
            </button>

            <a href="{{ route('loanbanks') }}" id="btnAddBank"
               class="btn btn-primary d-none">
                + Add Loan Bank
            </a>
        </div>
    </div>

    <!-- ================= CARDS ================= -->
    <div class="analytics-summary-grid">

        <div class="analytics-card blue-card active"
             onclick="showSection('online', this)">
            <div class="card-top">
                <div class="card-icon"><i class="fas fa-globe"></i></div>
                <div class="card-content">
                    <h3>Online Leads</h3>
                    <h2>{{ count($enquiries) }}</h2>
                </div>
            </div>
        </div>

        <div class="analytics-card green-card"
             onclick="showSection('all', this)">
            <div class="card-top">
                <div class="card-icon"><i class="fas fa-list"></i></div>
                <div class="card-content">
                    <h3>All Leads</h3>
                    <h2>{{ $leads->total() }}</h2>
                </div>
            </div>
        </div>

        <div class="analytics-card yellow-card"
             onclick="showSection('mis', this)">
            <div class="card-top">
                <div class="card-icon"><i class="fas fa-file-alt"></i></div>
                <div class="card-content">
                    <h3>All MIS</h3>
                    <h2>{{ $totalMIS }}</h2>
                </div>
            </div>
        </div>

        <div class="analytics-card green-card"
             onclick="showSection('banks', this)">
            <div class="card-top">
                <div class="card-icon"><i class="fas fa-university"></i></div>
                <div class="card-content">
                    <h3>Loan Banks</h3>
                    <h2>{{ $totalLoanBanks }}</h2>
                </div>
            </div>
        </div>

    </div>

    <!-- ================= TABLE WRAPPER ================= -->
    <div class="table-card-large mt-4">

        <h3 id="tableTitle">Online Leads</h3>
        <p id="tableSubTitle">Website enquiries</p>

        <!-- ===== ONLINE ===== -->
        <div id="section-online">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th><th>Name</th><th>Email</th><th>Contact</th><th>Message</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($enquiries as $e)
                    <tr>
                        <td>{{ $e->enquiry_id }}</td>
                        <td>{{ $e->name }}</td>
                        <td>{{ $e->email }}</td>
                        <td>{{ $e->contact }}</td>
                        <td>{{ $e->message }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

        <!-- ===== ALL LEADS ===== -->
        <div id="section-all" class="d-none">

            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Source</th>
                        <th>Follow-up</th>
                        <th>Agent</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                @foreach($leads as $index => $lead)
                    <tr>
                        <td>{{ $leads->firstItem() + $index }}</td>
                        <td>{{ $lead->name }}</td>
                        <td>{{ $lead->email }}</td>
                        <td>{{ $lead->phone }}</td>
                        <td>{{ $lead->lead_source }}</td>
                        <td>{{ $lead->follow_up_date ? \Carbon\Carbon::parse($lead->follow_up_date)->format('d M Y') : '-' }}</td>
                        <td>{{ $lead->agent->name ?? 'N/A' }}</td>

                        <td class="text-nowrap">
                            <!-- EDIT -->
                            <button class="btn btn-warning btn-sm editLeadBtn"
                                data-id="{{ $lead->id }}"
                                data-name="{{ $lead->name }}"
                                data-email="{{ $lead->email }}"
                                data-phone="{{ $lead->phone }}"
                                data-source="{{ $lead->lead_source }}"
                                data-agent="{{ $lead->assigned_to }}"
                                data-notes="{{ $lead->notes }}">
                                <i class="fa fa-edit"></i>
                            </button>

                            <!-- DELETE -->
                            
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

            {{ $leads->links() }}
        </div>

        <!-- ===== MIS ===== -->
        <div id="section-mis" class="d-none">
            <table class="table table-bordered">
                <thead><tr><th>Name</th><th>Amount</th><th>City</th></tr></thead>
                <tbody>
                @foreach($misRecords as $mis)
                    <tr>
                        <td>{{ $mis->name }}</td>
                        <td>{{ $mis->amount }}</td>
                        <td>{{ $mis->city }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{ $misRecords->links() }}
        </div>

        <!-- ===== BANKS ===== -->
        <div id="section-banks" class="d-none">
            <table class="table table-bordered">
                <thead><tr><th>Bank</th><th>IFSC</th><th>Branch</th></tr></thead>
                <tbody>
                @foreach($loanBanks as $b)
                    <tr>
                        <td>{{ $b->bank_name }}</td>
                        <td>{{ $b->ifsc_code }}</td>
                        <td>{{ $b->branch_name }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{ $loanBanks->links() }}
        </div>

    </div>
</div>

<!-- ================= ADD / EDIT MODAL ================= -->
<!-- ================= ADD / EDIT LEAD MODAL ================= -->
<div class="modal fade" id="leadModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">

            <form id="leadForm" method="POST">
                @csrf
                <input type="hidden" id="formMethod" name="_method">

                <div class="modal-header bg-primary text-white">
                    <h5 id="modalTitle">Add Lead</h5>
                    <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="row g-3">

                        <div class="col-md-3">
                            <label>Full Name *</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>

                        <div class="col-md-3">
                            <label>Email *</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>

                        <div class="col-md-3">
                            <label>Phone *</label>
                            <input type="text" id="phone" name="phone" class="form-control" required>
                        </div>

                        <div class="col-md-3">
                            <label>Alternate Phone</label>
                            <input type="text" id="alternate_phone" name="alternate_phone" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label>Lead Source *</label>
                            <select id="lead_source" name="lead_source" class="form-control" required>
                                <option value="Website">Website</option>
                                <option value="Referral">Referral</option>
                                <option value="Agent">Agent</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label>Property Type *</label>
                            <select id="property_type" name="property_type" class="form-control" required>
                                <option value="Apartment">Apartment</option>
                                <option value="Villa">Villa</option>
                                <option value="Commercial">Commercial</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label>Budget Min *</label>
                            <input type="number" id="budget_min" name="budget_min" class="form-control" required>
                        </div>

                        <div class="col-md-3">
                            <label>Budget Max *</label>
                            <input type="number" id="budget_max" name="budget_max" class="form-control" required>
                        </div>

                        <div class="col-md-4">
                            <label>Location Preference *</label>
                            <input type="text" id="location_preference" name="location_preference" class="form-control" required>
                        </div>

                        <div class="col-md-4">
                            <label>Possession Time *</label>
                            <select id="possession_time" name="possession_time" class="form-control" required>
                                <option value="Ready To Move">Ready To Move</option>
                                <option value="6 Months">6 Months</option>
                                <option value="1 Year">1 Year</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label>Lead Status *</label>
                            <select id="lead_status" name="lead_status" class="form-control" required>
                                <option value="New">New</option>
                                <option value="Contacted">Contacted</option>
                                <option value="Closed">Closed</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label>Assigned Agent *</label>
                            <select id="assigned_to" name="assigned_to" class="form-control" required>
                                @foreach($agents as $agent)
                                    <option value="{{ $agent->id }}">{{ $agent->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label>Follow-up Date</label>
                            <input type="date" id="follow_up_date" name="follow_up_date" class="form-control">
                        </div>

                        <div class="col-md-12">
                            <label>Notes</label>
                            <textarea id="notes" name="notes" class="form-control"></textarea>
                        </div>

                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-success" id="submitBtn">SAVE</button>
                </div>

            </form>

        </div>
    </div>
</div>


@endsection

@section('script')
<script>
function showSection(type, el){
    document.querySelectorAll('.analytics-card').forEach(c=>c.classList.remove('active'));
    el.classList.add('active');

    ['online','all','mis','banks'].forEach(s=>{
        document.getElementById('section-'+s).classList.add('d-none');
    });

    document.getElementById('section-'+type).classList.remove('d-none');

    const map={
        online:['Online Leads','Website enquiries'],
        all:['All Leads','All available leads'],
        mis:['All MIS','MIS records'],
        banks:['Loan Banks','Available banks']
    };

    tableTitle.innerText=map[type][0];
    tableSubTitle.innerText=map[type][1];
}

function openAddLead(){
    $('#leadForm')[0].reset();
    $('#modalTitle').text('Add Lead');
    $('#submitBtn').text('SAVE');
    $('#formMethod').val('');
    $('#leadForm').attr('action',"{{ route('leads.store') }}");
    $('#leadModal').modal('show');
}

$(document).on('click','.editLeadBtn',function(){

    $('#modalTitle').text('Update Lead');
    $('#submitBtn').text('UPDATE');

    $('#name').val($(this).data('name'));
    $('#email').val($(this).data('email'));
    $('#phone').val($(this).data('phone'));
    $('#alternate_phone').val($(this).data('alternate'));
    $('#lead_source').val($(this).data('source'));
    $('#property_type').val($(this).data('property'));
    $('#budget_min').val($(this).data('budgetmin'));
    $('#budget_max').val($(this).data('budgetmax'));
    $('#location_preference').val($(this).data('location'));
    $('#possession_time').val($(this).data('possession'));
    $('#lead_status').val($(this).data('status'));
    $('#assigned_to').val($(this).data('agent'));
    $('#follow_up_date').val($(this).data('followup'));
    $('#notes').val($(this).data('notes'));

    $('#formMethod').val('PUT');
    $('#leadForm').attr('action','/admin/leads/'+$(this).data('id'));

    $('#leadModal').modal('show');
});
</script>
@endsection
