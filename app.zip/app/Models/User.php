<?php
namespace App\Models;
// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
// use Spatie\Permission\Models\Role;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\CibilScore;
class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles;
    use SoftDeletes;

    protected $dates = ['deleted_at'];
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'mobile_no',
        'email_id',
        'password',
        'referral_code',
        'role_id',
        'email_otp',
        'email_verification_token',
        'email_otp_expires_at',
        'email_verified_at',
        'is_email_verify',
        'is_property_applied'

    ];
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];
    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'email_otp_expires_at' => 'datetime',
             'last_login_at'         => 'datetime', // ✅ ADD THIS
        ];
    }
    public function roles()
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }
    
    public function profile()
    {
        return $this->hasOne(Profile::class, 'user_id');
    }
    
    // Define relationship with Education
    public function education()
    {
        return $this->hasOne(Education::class, 'user_id');
    }
    // Define relationship with Professional
    public function professional()
    {
        return $this->hasOne(Professional::class, 'user_id');
    }
    public function loans()
    {
        return $this->hasMany(Loan::class, 'user_id', 'id');
    }

    public function cibilScore()
    {
        return $this->hasOne(CibilScore::class);
    }
}