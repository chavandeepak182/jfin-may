<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IsStakeholderMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Get role_id from session
        $role_id = session()->get('role_id');

        // 👉 Change this value according to your stakeholder role_id
        // Example: 3 = stakeholder
        if ($role_id == 6 || $role_id == 4) { // 4 = admin (optional access)
            return $next($request);
        }

        // Unauthorized access
        return redirect('/')->with('error', 'You are not authorized to access this page');
    }
}