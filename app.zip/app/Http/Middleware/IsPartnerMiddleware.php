<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IsPartnerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
{
    if(in_array(session('role_id'), [
        config('constants.roles.admin'),
        config('constants.roles.partner')
    ])){
        return $next($request);
    }

    return redirect('/dashboard');
}
}
